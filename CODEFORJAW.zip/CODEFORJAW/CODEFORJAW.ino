#include <WiFi.h>
#include <WebServer.h>
#include <Wire.h>
#include <Adafruit_PWMServoDriver.h>

// =====================================================
// WIFI
// =====================================================

const char* WIFI_SSID = "";
const char* WIFI_PASSWORD = "";

WebServer server(80);


// =====================================================
// PCA9685
// =====================================================

Adafruit_PWMServoDriver pwm = Adafruit_PWMServoDriver(0x40);


// =====================================================
// CHANNELS
// =====================================================

const int EYE_LR       = 0;
const int EYE_UD       = 1;

const int TOP_LEFT     = 2;
const int BOTTOM_LEFT  = 3;

const int TOP_RIGHT    = 4;
const int BOTTOM_RIGHT = 5;

const int MOUTH        = 6;


// =====================================================
// EYE LIMITS — SAME AS YOUR ORIGINAL
// =====================================================

const int LR_CENTER = 90;
const int LR_LEFT   = 62;
const int LR_RIGHT  = 118;

const int UD_CENTER = 90;
const int UD_UP     = 67;
const int UD_DOWN   = 113;


// =====================================================
// EYELIDS — SAME AS YOUR ORIGINAL
// =====================================================

const int TL_OPEN   = 105;
const int TL_CLOSED = 70;

const int BL_OPEN   = 75;
const int BL_CLOSED = 105;

const int TR_OPEN   = 75;
const int TR_CLOSED = 110;

const int BR_OPEN   = 105;
const int BR_CLOSED = 75;


// =====================================================
// MOUTH
//
// Website works with 0–100:
//
// 0   = closed
// 100 = fully open
//
// Your servo:
//
// 180° = closed
// 120° = fully open
// =====================================================

const int MOUTH_CLOSED = 180;
const int MOUTH_OPEN   = 120;


// =====================================================
// SERVO RANGE
// =====================================================

const int SERVO_MIN = 110;
const int SERVO_MAX = 510;


// =====================================================
// SERVO FUNCTIONS
// =====================================================

int angleToPulse(int angle)
{
  angle = constrain(angle, 0, 180);

  return map(
    angle,
    0,
    180,
    SERVO_MIN,
    SERVO_MAX
  );
}


void servoWrite(int channel, int angle)
{
  pwm.setPWM(
    channel,
    0,
    angleToPulse(angle)
  );
}


void releaseServo(int channel)
{
  pwm.setPWM(channel, 0, 0);
}


// =====================================================
// MOUTH
// =====================================================

int currentMouthOpen = 0;


void setMouth(int openness)
{
  openness = constrain(openness, 0, 100);

  currentMouthOpen = openness;

  int angle =
    map(
      openness,
      0,
      100,
      MOUTH_CLOSED,
      MOUTH_OPEN
    );

  servoWrite(MOUTH, angle);
}


// =====================================================
// MOUTH TIMELINE
// =====================================================

struct MouthFrame
{
  uint32_t time;
  uint8_t open;
};


const int MAX_FRAMES = 2500;

MouthFrame timeline[MAX_FRAMES];

int frameCount = 0;
int currentFrame = 0;

bool mouthPlaying = false;

uint32_t mouthStart = 0;


// =====================================================
// UPDATE MOUTH TIMELINE
// =====================================================

void updateMouth()
{
  if (!mouthPlaying)
    return;


  uint32_t elapsed =
    millis() - mouthStart;


  while (
    currentFrame < frameCount &&
    elapsed >= timeline[currentFrame].time
  )
  {
    setMouth(
      timeline[currentFrame].open
    );

    currentFrame++;
  }


  if (currentFrame >= frameCount)
  {
    mouthPlaying = false;

    setMouth(0);

    delay(20);

    releaseServo(MOUTH);
  }
}


// =====================================================
// START / STOP
// =====================================================

void startTimeline()
{
  if (frameCount == 0)
    return;


  currentFrame = 0;

  mouthStart = millis();

  mouthPlaying = true;


  setMouth(
    timeline[0].open
  );
}


void stopTimeline()
{
  mouthPlaying = false;

  currentFrame = 0;

  setMouth(0);

  delay(20);

  releaseServo(MOUTH);
}


// =====================================================
// EYE VARIABLES
// =====================================================

int currentLR = LR_CENTER;
int currentUD = UD_CENTER;

int targetLR = LR_CENTER;
int targetUD = UD_CENTER;

int startLR = LR_CENTER;
int startUD = UD_CENTER;

uint32_t eyeTimer = 0;


// =====================================================
// CHOOSE TARGET
//
// SAME TARGET LOGIC AS ORIGINAL
// =====================================================

void chooseTarget(
  int &newLR,
  int &newUD
)
{
  int attempts = 0;


  do
  {
    newLR =
      random(
        LR_LEFT,
        LR_RIGHT + 1
      );


    newUD =
      random(
        UD_UP,
        UD_DOWN + 1
      );


    attempts++;
  }

  while (
    abs(newLR - currentLR) < 18 &&
    abs(newUD - currentUD) < 9 &&
    attempts < 50
  );


  if (
    abs(newLR - currentLR) < 12 &&
    abs(newUD - currentUD) < 6
  )
  {
    if (currentLR >= LR_CENTER)
    {
      newLR =
        random(
          LR_LEFT,
          LR_CENTER - 8
        );
    }

    else
    {
      newLR =
        random(
          LR_CENTER + 8,
          LR_RIGHT + 1
        );
    }
  }
}


// =====================================================
// EYE STATE MACHINE
// =====================================================

enum EyeState
{
  EYE_WAIT,

  EYE_SACCADE,

  BLINK_EARLY,

  BLINK_HALF,

  BLINK_MIDDLE,

  BLINK_CLOSED,

  BLINK_OPEN,

  BLINK_FINISH
};


EyeState eyeState = EYE_WAIT;


// =====================================================
// SCHEDULE NEXT GAZE
//
// Same timing probabilities as original.
// =====================================================

void scheduleNextEyeAction()
{
  int type = random(100);

  uint32_t waitTime;


  if (type < 25)
  {
    waitTime =
      random(250, 450);
  }

  else if (type < 80)
  {
    waitTime =
      random(450, 850);
  }

  else if (type < 95)
  {
    waitTime =
      random(850, 1300);
  }

  else
  {
    waitTime =
      random(1300, 2000);
  }


  eyeTimer =
    millis() + waitTime;


  eyeState =
    EYE_WAIT;
}


// =====================================================
// UPDATE EYES
// =====================================================

void updateEyes()
{
  uint32_t now = millis();


  // ===================================================
  // WAIT AT CURRENT GAZE
  // ===================================================

  if (eyeState == EYE_WAIT)
  {
    if ((int32_t)(now - eyeTimer) < 0)
      return;


    // Same 15% chance of movement without blink.

    if (random(100) < 15)
    {
      chooseTarget(
        targetLR,
        targetUD
      );


      servoWrite(
        EYE_LR,
        targetLR
      );


      servoWrite(
        EYE_UD,
        targetUD
      );


      currentLR = targetLR;
      currentUD = targetUD;


      eyeTimer =
        now + 35;


      eyeState =
        EYE_SACCADE;


      return;
    }


    // Otherwise do blink + gaze change.

    chooseTarget(
      targetLR,
      targetUD
    );


    startLR = currentLR;
    startUD = currentUD;


    int earlyLR =
      startLR +
      ((targetLR - startLR) * 0.35);


    int earlyUD =
      startUD +
      ((targetUD - startUD) * 0.35);


    servoWrite(
      EYE_LR,
      earlyLR
    );


    servoWrite(
      EYE_UD,
      earlyUD
    );


    eyeTimer =
      now + 4;


    eyeState =
      BLINK_HALF;


    return;
  }


  // ===================================================
  // SACCADE WITHOUT BLINK
  // ===================================================

  if (eyeState == EYE_SACCADE)
  {
    if ((int32_t)(now - eyeTimer) < 0)
      return;


    releaseServo(EYE_LR);
    releaseServo(EYE_UD);


    // Original code had brief fixation before blink.

    eyeTimer =
      now +
      random(180, 450);


    eyeState =
      BLINK_EARLY;


    return;
  }


  // ===================================================
  // AFTER RARE SACCADE:
  // NOW BLINK + MOVE AGAIN
  // ===================================================

  if (eyeState == BLINK_EARLY)
  {
    if ((int32_t)(now - eyeTimer) < 0)
      return;


    chooseTarget(
      targetLR,
      targetUD
    );


    startLR = currentLR;
    startUD = currentUD;


    int earlyLR =
      startLR +
      ((targetLR - startLR) * 0.35);


    int earlyUD =
      startUD +
      ((targetUD - startUD) * 0.35);


    servoWrite(
      EYE_LR,
      earlyLR
    );


    servoWrite(
      EYE_UD,
      earlyUD
    );


    eyeTimer =
      now + 4;


    eyeState =
      BLINK_HALF;


    return;
  }


  // ===================================================
  // HALF CLOSE
  // ===================================================

  if (eyeState == BLINK_HALF)
  {
    if ((int32_t)(now - eyeTimer) < 0)
      return;


    servoWrite(
      TOP_LEFT,
      (TL_OPEN + TL_CLOSED) / 2
    );

    servoWrite(
      BOTTOM_LEFT,
      (BL_OPEN + BL_CLOSED) / 2
    );

    servoWrite(
      TOP_RIGHT,
      (TR_OPEN + TR_CLOSED) / 2
    );

    servoWrite(
      BOTTOM_RIGHT,
      (BR_OPEN + BR_CLOSED) / 2
    );


    int middleLR =
      startLR +
      ((targetLR - startLR) * 0.75);


    int middleUD =
      startUD +
      ((targetUD - startUD) * 0.75);


    servoWrite(
      EYE_LR,
      middleLR
    );


    servoWrite(
      EYE_UD,
      middleUD
    );


    eyeTimer =
      now + 6;


    eyeState =
      BLINK_CLOSED;


    return;
  }


  // ===================================================
  // CLOSE
  // ===================================================

  if (eyeState == BLINK_CLOSED)
  {
    if ((int32_t)(now - eyeTimer) < 0)
      return;


    servoWrite(
      TOP_LEFT,
      TL_CLOSED
    );

    servoWrite(
      BOTTOM_LEFT,
      BL_CLOSED
    );

    servoWrite(
      TOP_RIGHT,
      TR_CLOSED
    );

    servoWrite(
      BOTTOM_RIGHT,
      BR_CLOSED
    );


    servoWrite(
      EYE_LR,
      targetLR
    );


    servoWrite(
      EYE_UD,
      targetUD
    );


    currentLR =
      targetLR;


    currentUD =
      targetUD;


    eyeTimer =
      now +
      random(25, 50);


    eyeState =
      BLINK_OPEN;


    return;
  }


  // ===================================================
  // OPEN
  // ===================================================

  if (eyeState == BLINK_OPEN)
  {
    if ((int32_t)(now - eyeTimer) < 0)
      return;


    servoWrite(
      TOP_LEFT,
      TL_OPEN
    );

    servoWrite(
      BOTTOM_LEFT,
      BL_OPEN
    );

    servoWrite(
      TOP_RIGHT,
      TR_OPEN
    );

    servoWrite(
      BOTTOM_RIGHT,
      BR_OPEN
    );


    eyeTimer =
      now + 35;


    eyeState =
      BLINK_FINISH;


    return;
  }


  // ===================================================
  // FINISH BLINK
  // ===================================================

  if (eyeState == BLINK_FINISH)
  {
    if ((int32_t)(now - eyeTimer) < 0)
      return;


    releaseServo(EYE_LR);
    releaseServo(EYE_UD);

    releaseServo(TOP_LEFT);
    releaseServo(BOTTOM_LEFT);

    releaseServo(TOP_RIGHT);
    releaseServo(BOTTOM_RIGHT);


    scheduleNextEyeAction();
  }
}


// =====================================================
// CORS
// =====================================================

void sendCors()
{
  server.sendHeader(
    "Access-Control-Allow-Origin",
    "*"
  );

  server.sendHeader(
    "Access-Control-Allow-Methods",
    "GET,POST,OPTIONS"
  );

  server.sendHeader(
    "Access-Control-Allow-Headers",
    "Content-Type"
  );
}


// =====================================================
// STATUS
// =====================================================

void handleStatus()
{
  sendCors();


  String json = "{";

  json += "\"online\":true,";

  json += "\"frames\":";
  json += frameCount;
  json += ",";

  json += "\"playing\":";
  json += mouthPlaying ? "true" : "false";
  json += ",";

  json += "\"mouth\":";
  json += currentMouthOpen;

  json += "}";


  server.send(
    200,
    "application/json",
    json
  );
}


// =====================================================
// MANUAL MOUTH
//
// POST /mouth?open=50
// =====================================================

void handleMouth()
{
  sendCors();


  if (!server.hasArg("open"))
  {
    server.send(
      400,
      "application/json",
      "{\"error\":\"missing open\"}"
    );

    return;
  }


  int amount =
    server.arg("open").toInt();


  setMouth(amount);


  server.send(
    200,
    "application/json",
    "{\"ok\":true}"
  );
}


// =====================================================
// RECEIVE TIMELINE
//
// FORMAT:
//
// 0,0
// 40,12
// 80,36
// 120,75
// 160,100
// 220,55
// 300,0
//
// time(ms), openness(0-100)
// =====================================================

void handleTimeline()
{
  sendCors();


  if (!server.hasArg("plain"))
  {
    server.send(
      400,
      "application/json",
      "{\"error\":\"no timeline\"}"
    );

    return;
  }


  String data =
    server.arg("plain");


  frameCount = 0;


  int position = 0;


  while (
    position < data.length() &&
    frameCount < MAX_FRAMES
  )
  {
    int end =
      data.indexOf(
        '\n',
        position
      );


    if (end == -1)
      end = data.length();


    String line =
      data.substring(
        position,
        end
      );


    line.trim();


    int comma =
      line.indexOf(',');


    if (comma > 0)
    {
      uint32_t frameTime =
        line.substring(
          0,
          comma
        ).toInt();


      int openness =
        line.substring(
          comma + 1
        ).toInt();


      openness =
        constrain(
          openness,
          0,
          100
        );


      timeline[frameCount].time =
        frameTime;


      timeline[frameCount].open =
        openness;


      frameCount++;
    }


    position =
      end + 1;
  }


  setMouth(0);


  String result =
    "{\"loaded\":true,\"frames\":" +
    String(frameCount) +
    "}";


  server.send(
    200,
    "application/json",
    result
  );
}


// =====================================================
// START
// =====================================================

void handleStart()
{
  sendCors();


  if (frameCount == 0)
  {
    server.send(
      400,
      "application/json",
      "{\"error\":\"no timeline loaded\"}"
    );

    return;
  }


  startTimeline();


  server.send(
    200,
    "application/json",
    "{\"started\":true}"
  );
}


// =====================================================
// STOP
// =====================================================

void handleStop()
{
  sendCors();


  stopTimeline();


  server.send(
    200,
    "application/json",
    "{\"stopped\":true}"
  );
}


// =====================================================
// OPTIONS FOR BROWSER CORS
// =====================================================

void handleOptions()
{
  sendCors();

  server.send(
    204,
    "text/plain",
    ""
  );
}


// =====================================================
// SETUP
// =====================================================

void setup()
{
  Serial.begin(115200);


  // SAME I2C INITIALIZATION AS YOUR WORKING CODE

  Wire.begin();


  pwm.begin();


  pwm.setOscillatorFrequency(
    27000000
  );


  pwm.setPWMFreq(50);


  randomSeed(
    micros()
  );


  delay(500);


  // ===================================================
  // INITIAL EYES
  // ===================================================

  servoWrite(
    EYE_LR,
    LR_CENTER
  );


  servoWrite(
    EYE_UD,
    UD_CENTER
  );


  servoWrite(
    TOP_LEFT,
    TL_OPEN
  );


  servoWrite(
    BOTTOM_LEFT,
    BL_OPEN
  );


  servoWrite(
    TOP_RIGHT,
    TR_OPEN
  );


  servoWrite(
    BOTTOM_RIGHT,
    BR_OPEN
  );


  // Mouth closed

  setMouth(0);


  delay(600);


  releaseServo(EYE_LR);
  releaseServo(EYE_UD);

  releaseServo(TOP_LEFT);
  releaseServo(BOTTOM_LEFT);

  releaseServo(TOP_RIGHT);
  releaseServo(BOTTOM_RIGHT);

  releaseServo(MOUTH);


  currentLR = LR_CENTER;
  currentUD = UD_CENTER;


  scheduleNextEyeAction();


  // ===================================================
  // WIFI
  // ===================================================

  WiFi.begin(
    WIFI_SSID,
    WIFI_PASSWORD
  );


  Serial.println();

  Serial.print(
    "Connecting to WiFi"
  );


  while (
    WiFi.status() != WL_CONNECTED
  )
  {
    delay(250);

    Serial.print(".");
  }


  Serial.println();

  Serial.println(
    "CONNECTED!"
  );


  Serial.print(
    "ESP32 IP: "
  );


  Serial.println(
    WiFi.localIP()
  );


  // ===================================================
  // ROUTES
  // ===================================================

  server.on(
    "/status",
    HTTP_GET,
    handleStatus
  );


  server.on(
    "/mouth",
    HTTP_POST,
    handleMouth
  );


  server.on(
    "/timeline",
    HTTP_POST,
    handleTimeline
  );


  server.on(
    "/start",
    HTTP_POST,
    handleStart
  );


  server.on(
    "/stop",
    HTTP_POST,
    handleStop
  );


  server.on(
    "/status",
    HTTP_OPTIONS,
    handleOptions
  );


  server.on(
    "/mouth",
    HTTP_OPTIONS,
    handleOptions
  );


  server.on(
    "/timeline",
    HTTP_OPTIONS,
    handleOptions
  );


  server.on(
    "/start",
    HTTP_OPTIONS,
    handleOptions
  );


  server.on(
    "/stop",
    HTTP_OPTIONS,
    handleOptions
  );


  server.begin();


  Serial.println(
    "Animatronic controller ready."
  );
}


// =====================================================
// LOOP
// =====================================================

void loop()
{
  // Receive localhost commands.
  server.handleClient();


  // Keep mouth timeline synchronized.
  updateMouth();


  // Keep eyes alive independently.
  updateEyes();


  // Important for ESP32 background tasks.
  delay(1);
}